package at.campus02.swd.game.gameobjects;

public class MeadowTile extends Tile{

    public MeadowTile(String path) {
        super(path);
    }
}
