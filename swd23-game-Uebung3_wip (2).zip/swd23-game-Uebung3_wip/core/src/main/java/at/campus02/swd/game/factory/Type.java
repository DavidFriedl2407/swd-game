package at.campus02.swd.game.factory;

public enum Type {
    MEADOW_TOP_LEFT,
    MEADOW_TOP,
    MEADOW_TOP_RIGHT,
    MEADOW_RIGHT,
    MEADOW_LEFT,
    MEADOW_CENTER,
    MEADOW_BOTTOM_LEFT,
    MEADOW_BOTTOM,
    MEADOW_BOTTOM_RIGHT,
    PLAYER,
    ENEMY1,
    ENEMY2
}
