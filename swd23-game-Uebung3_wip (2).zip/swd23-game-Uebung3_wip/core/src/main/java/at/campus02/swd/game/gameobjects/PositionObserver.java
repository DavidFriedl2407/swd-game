package at.campus02.swd.game.gameobjects;

import at.campus02.swd.game.gameobjects.GameObject;

public interface PositionObserver {
    void updatePosition(int x, int y);
}
